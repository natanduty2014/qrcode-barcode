package demogradle;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class FileToHex {

    // private static final String NEW_LINE = System.lineSeparator();
    private static final String UNKNOWN_CHARACTER = ".";

    public static void main(String[] args) throws IOException {
        //buscar arquivo
        String file = "./img/codigodebarras.png";
        
        //fazer o buffe da img para verificar altura e largura
        BufferedImage imagem = ImageIO.read(new File(file));
        int width          = imagem.getWidth();
        int height         = imagem.getHeight();

        // redimencionar imagem
        int new_w = 320, new_h = 240;
        //TYPE_BYTE_GRAY deixar a img em sinza
        //TYPE_BYTE_BINARY deixar em preto e branco
        //TYPE_4BYTE_ABGR_PRE fundo transparente e colorida
        BufferedImage new_img = new BufferedImage(new_w, new_h, BufferedImage.TYPE_BYTE_GRAY);
        System.out.println("Largura:"+width);
        System.out.println("Altura:"+height);
        Graphics2D g = new_img.createGraphics();
        g.drawImage(imagem, 0, 0, new_w, new_h, null);
        //salvar imagem redimencionada
        ImageIO.write(new_img, "png", new File("file.png"));
        //teste
        
        //teste
        //buscar a class e imprimir em hex
        String syshex = convertFileToHex(Paths.get(file));
        System.out.println(syshex);
    }

    public static String convertFileToHex(Path path) throws IOException {

        if (Files.notExists(path)) {
            throw new IllegalArgumentException("File not found! " + path);
        }

        StringBuilder result = new StringBuilder();
        StringBuilder hex = new StringBuilder();
        StringBuilder input = new StringBuilder();

        int count = 0;
        int value;

        // path to inputstream....
        try (InputStream inputStream = Files.newInputStream(path)) {

            while ((value = inputStream.read()) != -1) {

                hex.append(String.format("%02X ", value));

                // If the character is unable to convert, just prints a dot "."
                if (!Character.isISOControl(value)) {
                    input.append((char) value);
                } else {
                    input.append(UNKNOWN_CHARACTER);
                }

                // Separar em bloco de 256 bytes em hex
                if (count == 256) {
                    // result.append(String.format("%-60s | %s%n", hex, input));
                    System.out.println(hex);
                    hex.setLength(0);
                    input.setLength(0);
                    count = 0;
                } else {
                    count++;
                }

            }

            // if the count>0, meaning there is remaining content
            if (count > 0) {
                result.append(hex);
                /*
                 * String nome = "./qrcodee.png"; File f = new File(nome); f.delete();
                 */
                // result.append(String.format("%-60s", hex));

            }

        }

        return result.toString();
    }

}