package demogradle;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Qrcode {
    public static void main(String... args) {
        try {
            // o texto a ser transformado em qrcode
            String contents = "Hex to img. testando qrcode 01";
            // buscar arquivo
            String fileName = "./img/qrcode.png";
            // tamanho do qrcode
            int width = 400;
            int height = 400;

            // gerar QR code
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(contents, BarcodeFormat.QR_CODE, width, height);

            // Salvar qrcode
            Path filePath = Paths.get(fileName);
            MatrixToImageWriter.writeToPath(bitMatrix, "PNG", filePath);
            System.out.println("Criado Qrcode");
        } catch (WriterException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
