package demogradle;

import java.nio.file.Path;
import java.nio.file.Paths;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.oned.Code128Writer;

public class Barcode {
    public static void main(String[] args) throws Exception {
        try {
            // texto a ser codificado em barcode
            String text = "Codigo de barras ldslfldfnla";
            // pasta a ser salva a img
            String path = "./img/codigodebarras.png";
            Code128Writer writer = new Code128Writer();
            // altura e largura
            int w = 500;
            int h = 300;
            BitMatrix matrix = writer.encode(text, BarcodeFormat.CODE_128, w, h);
            Path filePath = Paths.get(path);
            MatrixToImageWriter.writeToPath(matrix, "PNG", filePath);
            System.out.println("Barcode Criado");
        } catch (Exception e) {
            System.out.println("erro ao criar barcoder ->" + e);
        }
    }

}
